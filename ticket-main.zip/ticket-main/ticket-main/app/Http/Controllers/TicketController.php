<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Models\Mensagem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class TicketController extends Controller
{

    public function __construct()
    {
        $this->middleware(['auth', 'profile_is_null', 'funcionario_pendente', 'status_inactived']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        Gate::authorize('admin_or_funcionario');

        $status = 'aberto';
        if ($request->status)
            $status = $request->status;

        $tickets = Ticket::with('user')->where('status', $status)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        // add atributos na url, ex: ?teste=1&page=2
        $tickets->appends(request()->input())->links();

        $total = [
            'aberto' => Ticket::where('status', 'aberto')->count(),
            'fechado' => Ticket::where('status', 'fechado')->count(),
        ];

        return view('dashboard.tickets.tickets', compact(['tickets', 'total']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        Gate::authorize('cliente');

        $ticket = [
            'ticketsAberto' => Ticket::where('user_id', auth()->user()->id)->where('status', 'aberto')->count(),
            'ticketsFechado' => Ticket::where('user_id', auth()->user()->id)->where('status', 'fechado')->count(),
            'ticketsTotal' => Ticket::where('user_id', auth()->user()->id)->count(),
        ];
        return view('dashboard.tickets.enviar_ticket', compact('ticket'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'assunto' => ['required', 'min:3'],
            'descricao' => ['required', 'min:3'],
            'prioridade' => ['required'],
            'assunto' => ['required', 'min:3'],
            'nome_autor' => ['required'],
        ]);

        $ticket = (new Ticket)->fill($request->all());
        $ticket->user_id = auth()->user()->id;
        $ticket->save();

        Mensagem::create([
            'descricao' => $request->descricao,
            'ticket_id' => $ticket->id,
            'nome_autor' => $request->nome_autor,
        ]);

        return redirect()->back()->with(['success' => true]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function show($ticket)
    {

        if (auth()->user()->profile == 'employee' || auth()->user()->profile == 'administrator') {
            $ticket = Ticket::with('mensagem')->find($ticket);
        } else {
            $ticket = Ticket::with('mensagem')->where('user_id', auth()->user()->id)->find($ticket);
        }

        return view('dashboard.tickets.ticket', compact('ticket'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function edit(Ticket $ticket)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ticket $ticket)
    {
        //
    }

    public function meusTickets(Request $request)
    {
        Gate::authorize('cliente');

        $status = 'aberto';
        if ($request->status)
            $status = $request->status;

        $tickets = Ticket::where('user_id', auth()->user()->id)
            ->where('status', $status)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        // add atributos na url, ex: ?teste=1&page=2
        $tickets->appends(request()->input())->links();

        $total = [
            'aberto' => Ticket::where('user_id', auth()->user()->id)->where('status', 'aberto')->count(),
            'fechado' => Ticket::where('user_id', auth()->user()->id)->where('status', 'fechado')->count(),
        ];

        return view('dashboard.tickets.meus_tickets', compact(['tickets', 'total']));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ticket $ticket)
    {
        Gate::authorize('admin_or_funcionario');
        $ticket->delete();
        return redirect()->back()->with(['success_msg' => 'Ticket removido com sucesso']);
    }

    public function responderTicket(Request $request)
    {

        $request->validate([
            'descricao' => ['required'],
            'ticket_id' => ['required'],
            'nome_autor' => ['required'],
        ], [], [
            'descricao' => 'responder'
        ]);

        Mensagem::create([
            'descricao' => $request->descricao,
            'ticket_id' => $request->ticket_id,
            'nome_autor' => $request->nome_autor,
        ]);

        return redirect()->back()->with(['success' => true]);
    }

    public function mudarStatus(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'status' => 'required',
        ]);

        $ticket = Ticket::find($request->id);
        if (
            auth()->user()->profile == 'employee' ||
            auth()->user()->profile == 'administrator' ||
            $ticket->user_id == auth()->user()->id
        ) {
            $ticket->status = $request->status;
            $ticket->save();
            return redirect()->back()->with(['success_msg' => 'Status atualizado com sucesso!']);
        }

        return redirect()->back();
    }
}
