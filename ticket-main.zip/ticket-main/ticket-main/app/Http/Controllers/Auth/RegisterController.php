<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {

        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
        ]);
    }

    public function addAdminView()
    {
        return view('dashboard.usuarios.adicionar_admin');
    }

    public function addAdmin(Request $request)
    {
        if (User::exists())
            Gate::authorize('admin');

        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'profile' => 'administrator',
            'password' => Hash::make($request['password']),

        ]);

        return redirect()->back()->with(['success' => true]);
    }
    
    /**
     * Vai redirecionar para página de permitir login com , google, facebook
     *
     * @param  mixed $provider
     * @return void
     */
    public function authSocialiteRedirect($provider)
    {
        // return Socialite::driver('github')->redirect();
        return Socialite::driver($provider)->redirect();
    }
        
    /**
     * vai redirecionar após fazer o login, ex: do google para nossa página
     *
     * @param  mixed $provider
     * @return void
     */
    public function authSocialiteCallback($provider)
    {
        $userProvider = Socialite::driver($provider)->user();

        // fazendo o login
        $user = User::firstOrCreate([
            'email' => $userProvider->getEmail(),
            'name' => $userProvider->getName() ?? $userProvider->getNickname(),
            'provider_id' => $userProvider->getId(),
            'provider' => $provider
        ]);

        Auth::login($user);

        return redirect()->route('home');
    }
}
