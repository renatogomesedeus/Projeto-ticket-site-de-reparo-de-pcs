<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Ticket;
use App\Models\Visualizacoes;
use Illuminate\Support\Facades\Gate;

class EstatisticaController extends Controller
{

    public function index()
    {
        $this->middleware(['auth', 'profile_is_null', 'status_inactived']);
        Gate::authorize('admin');

        $data = [
            'dadosUsuarios' => $this->dadosUsuarios(),
            'visualizacoesMes' => $this->visualizacoesMes(),
            'visualizacoesDiarias' => $this->visualizacoesDiarias(),
            'ticketsDiarios' => $this->ticketsDiarios(),
            'ticketsMes' => $this->ticketsMes(),
        ];

        return view('dashboard.estatisticas.estatisticas', ['data' => json_encode($data)]);
    }

    /**
     * dadosUsuarios
     *
     * @return array
     */
    public function dadosUsuarios(): array
    {
        $dadosUsuarios = [
            User::where('profile', 'client')->count(), // totalCliente
            User::where('profile', 'employee')->count(), // totalFuncionario
            User::where('profile', 'administrator')->count(), // totalAdmin
            User::all()->count(), // totalUsuarios
        ];

        return $dadosUsuarios;
    }

    /**
     * ticketsMes
     *
     * @return array
     */
    public function ticketsMes(): array
    {
        $vTicktesMes = Ticket::orderBy('created_at', 'desc')
            ->get()
            ->groupBy(function ($data) {
                return $data->created_at->format('Y-m');
            });

        $ticketsMes = ['mes' => [], 'tickets' => []];

        $iteracao = 0;
        foreach ($vTicktesMes as $value) {

            if ($iteracao >= 12)
                break;

            array_push($ticketsMes['mes'], $value[0]->mes_ano);
            array_push(
                $ticketsMes['tickets'],
                count($value)
            );

            $iteracao++;
        }

        return $ticketsMes;
    }


    /**
     * ticketsDiarios
     *
     * @return array
     */
    public function ticketsDiarios(): array
    {
        $vTicktesDiarios = Ticket::orderBy('created_at', 'desc')
            ->get()
            ->groupBy(function ($data) {
                return $data->created_at->format('Y-m-d');
            });

        $ticketsDiarios = ['dia' => [], 'tickets' => []];

        $iteracao = 0;
        foreach ($vTicktesDiarios as $value) {

            if ($iteracao >= 20)
                break;

            array_push($ticketsDiarios['dia'], $value[0]->dia_mes);
            array_push(
                $ticketsDiarios['tickets'],
                count($value)
            );

            $iteracao++;
        }

        return $ticketsDiarios;
    }

    /**
     * visualizacoesMes
     *
     * @return array
     */
    public function visualizacoesMes(): array
    {
        $vMes = Visualizacoes::orderBy('created_at', 'desc')
            ->get()
            ->groupBy(function ($data) {
                return $data->created_at->format('Y-m');
            });

        $visualizacoesMes = ['mes' => [], 'views' => []];

        $iteracao = 0;
        foreach ($vMes as $value) {
            if ($iteracao >= 12)
                break;

            array_push($visualizacoesMes['mes'], $value[0]->mes_ano);
            array_push(
                $visualizacoesMes['views'],
                array_sum(array_column(json_decode(json_encode($value)), 'views'))
            );

            $iteracao++;
        }

        return $visualizacoesMes;
    }


    /**
     * visualizacoesDiarias
     *
     * @return array
     */
    public function visualizacoesDiarias(): array
    {
        $vDiarias = Visualizacoes::orderBy('created_at', 'desc')
            ->limit(7)
            ->get();
        $visualizacoesDiarias = ['data' => [], 'views' => []];

        $iteracao = 0;
        foreach ($vDiarias as $value) {
            if ($iteracao >= 31)
                break;

            array_push($visualizacoesDiarias['data'], $value['dia_mes']);
            array_push($visualizacoesDiarias['views'], $value['views']);

            $iteracao++;
        }

        return $visualizacoesDiarias;
    }


    /**
     * somarVisualizacao
     *
     * @return bool
     */
    public function somarVisualizacao(): bool
    {
        $views = Visualizacoes::orderBy('created_at', 'desc')->first();
        if (Visualizacoes::exists()) {
            $date = $views->created_at->format('Y-m-d');
            if ($date == date('Y-m-d')) {
                $views->update(['views' => $views->views + 1]);
            } else {
                Visualizacoes::create(['views' => 1]);
            }
        } else {
            Visualizacoes::create(['views' => 1]);
        }
        return true;
    }
}
