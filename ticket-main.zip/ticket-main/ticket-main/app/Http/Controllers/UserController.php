<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Exports\UsersExport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Maatwebsite\Excel\Facades\Excel;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'profile_is_null', 'funcionario_pendente', 'status_inactived']);
    }

    public function index(Request $request)
    {

        Gate::authorize('admin_or_funcionario');

        $profile = [
            1 => 'administrator',
            2 => 'employee',
            3  => 'client',
        ];

        if ($request->profile) {
            $users = User::where('profile', $profile[$request->profile])
                ->orderBy('created_at', 'desc')
                ->paginate(10);
        } else {
            $users = User::orderBy('created_at', 'desc')->paginate(10);
        }

        // add atributos na url, ex: ?teste=1&page=2
        $users->appends(request()->input())->links();

        return view('dashboard.usuarios.usuarios', compact('users'));
    }

    public function desativarConta(User $user)
    {
        Gate::authorize('admin_or_funcionario');

        if ($user->profile != 'administrator') {
            $user->update(['status' => 'inactived']);
            return redirect()->back()->with(['success' => 'Conta desativado com sucesso']);
        } else {
            Gate::authorize('admin');
        }
    }

    public function ativarConta(User $user)
    {
        Gate::authorize('admin');
        $user->update(['status' => 'actived']);
        return redirect()->back()->with(['success' => 'Conta ativada com sucesso']);
    }

    public function aprovarConta(User $user)
    {
        Gate::authorize('admin_or_funcionario');
        $user->update(['status' => 'actived']);
        return redirect()->back()->with(['success' => 'Conta aprovada com sucesso']);
    }

    public function tornarAdmin(User $user)
    {
        Gate::authorize('admin');
        $user->update(['profile' => 'administrator']);
        return redirect()->back()->with(['success' => 'Perfil atualizado com sucesso']);
    }

    public function deletarUser(User $user)
    {
        Gate::authorize('admin');
        $user->delete();
        return redirect()->back()->with(['success' => 'Conta deletado com sucesso']);
    }

    public function exportarUsuariosView()
    {
        Gate::authorize('admin');
        $users = [
            'totalClientes' => User::where('profile', 'client')->count(),
            'totalFuncionarios' => User::where('profile', 'employee')->count(),
            'totalAdmin' => User::where('profile', 'administrator')->count(),
        ];
        return view('dashboard.usuarios.exportar_usuarios', compact('users'));
    }

    public function exportarUsuarios(Request $request)
    {
        Gate::authorize('admin');

        return Excel::download(
            new UsersExport,
            'usuarios.' . strtolower($request->formato),
            ucfirst(strtolower(str_replace('PDF', 'DOMPDF', $request->formato)))
        );
    }
}
