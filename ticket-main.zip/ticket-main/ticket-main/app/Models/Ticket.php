<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable= ['assunto', 'user_id', 'status', 'prioridade'];

    public function mensagem()
    {
       return $this->hasMany(Mensagem::class);
    }

    public function user()
    {
       return $this->belongsTo(User::class);
    }

    protected $appends= [
        'mes_ano', 
        'dia_mes',
    ];

    public function getMesAnoAttribute()
    {
        return $this->created_at->format('m-Y');
    }
    public function getDiaMesAttribute()
    {
        return $this->created_at->format('d/m');
    }
}
