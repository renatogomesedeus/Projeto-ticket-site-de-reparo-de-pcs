<?php

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\InicioController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\EstatisticaController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\CompleteRegistrationController;

Route::get('/', [InicioController::class, 'index']);
Auth::routes();

// Auth com Socialite
Route::get('/auth/redirect/{provider}', [RegisterController::class, 'authSocialiteRedirect'])
    ->name('auth.social');
Route::get('/auth/{provider}/callback', [RegisterController::class, 'authSocialiteCallback']);

// home dashboard
Route::get('/home', [HomeController::class, 'index'])->name('home');

// Usuários
// Route::get('/usuarios', [UserController::class, 'index'])->name('usuarios');
// Route::get('/usuarios/desativar/{user}', [UserController::class, 'desativarConta'])->name('desativar_conta');
// Route::get('/usuarios/ativar/{user}', [UserController::class, 'ativarConta'])->name('ativar_conta');
// Route::get('/usuarios/aprovar/{user}', [UserController::class, 'aprovarConta'])->name('aprovar_conta');
// Route::get('/usuarios/tarnar-admin/{user}', [UserController::class, 'tornarAdmin'])->name('tornar_admin');
// Route::get('/usuarios/deletar/{user}', [UserController::class, 'deletarUser'])->name('deletar_user');

Route::prefix('usuarios')->group(function () {
    Route::get('/', [UserController::class, 'index'])->name('usuarios');
    Route::get('/desativar/{user}', [UserController::class, 'desativarConta'])->name('desativar_conta');
    Route::get('/ativar/{user}', [UserController::class, 'ativarConta'])->name('ativar_conta');
    Route::get('/aprovar/{user}', [UserController::class, 'aprovarConta'])->name('aprovar_conta');
    Route::get('/tarnar-admin/{user}', [UserController::class, 'tornarAdmin'])->name('tornar_admin');
    Route::get('/deletar/{user}', [UserController::class, 'deletarUser'])->name('deletar_user');
    // Exportar usuários
    Route::get('/exportar', [UserController::class, 'exportarUsuariosView'])->name('exportar_usuarios');
    Route::post('/exportar', [UserController::class, 'exportarUsuarios'])->name('usuarios.exportar');
});


// Estatísticas
Route::prefix('estatisticas')->group(function () {
    Route::get('/', [EstatisticaController::class, 'index'])->name('estatisticas');
    Route::get('/visualizacao', [EstatisticaController::class, 'somarVisualizacao'])
        ->name('contar_visualizacao');
});

// Tickets
Route::get('/tickets/meus-tickets', [TicketController::class, 'meusTickets'])->name('meus_tickets');
Route::get('/tickets/mudar_status', [TicketController::class, 'mudarStatus'])->name('tickets.mudar_status');
Route::post('/tickets/responder', [TicketController::class, 'responderTicket'])->name('responderTicket');
Route::resource('/tickets', TicketController::class);
Route::get('/tickets', [TicketController::class, 'index'])->name('tickets');

// Concluir cadastro
Route::get('/concluir-cadastro', [CompleteRegistrationController::class, 'concluirCadastroSeProfileNull'])
    ->name('profile_is_null');
Route::put('/concluir-cadastro', [CompleteRegistrationController::class, 'updateUserProfile'])
    ->name('updateUserProfile');

// Add admin
Route::get('/adicionar-admin', [RegisterController::class, 'addAdminView'])->name('adicionar_admin');
Route::post('/adicionar-admin', [RegisterController::class, 'addAdmin'])->name('post_adicionar_admin');

// Funcionario pendente
Route::get('/funcionario-pendente', function () {
    return view('dashboard.usuarios.funcionario_pendente');
})->name('funcionario_pendente');

// Conta desativada
Route::get('/conta-desativada', function () {
    return view('dashboard.usuarios.conta_desativada');
})->name('conta_desativada');
