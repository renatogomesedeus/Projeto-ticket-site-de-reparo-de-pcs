// var xhr = new XMLHttpRequest();
// xhr.open("GET", "/contar-visualizacao?_method=POST");
// xhr.onload = function(e) {
//     if (xhr.readyState === 4) {
//         if (xhr.status === 200) {
//             // console.log(xhr.responseText);
//         } else {
//             // console.error(xhr.statusText);
//         }
//     }
// };

// xhr.send();



window.onload = function() {
    let ajax = new XMLHttpRequest();
    ajax.open('GET', '/estatisticas/visualizacao?_method=POST');
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            // console.log(ajax.responseText)
        }
        if (ajax.readyState == 4 && ajax.status == 404) {
            // console.log(ajax.responseText)
        }
    }
    ajax.send();
}