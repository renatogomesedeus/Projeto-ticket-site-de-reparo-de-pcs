@extends('layouts.layout_dashboard')

@section('content')
    <div class="">

        @if (session('cadastro_concluido'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2 fa-lg"></i>
                <strong>Cadastro concluído com sucesso!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        {{-- view admin e funcionário --}}
        @can('admin_or_funcionario')
            <x-content-home-admin :usersTotal="$usersTotal" :usersPrevia="$usersPrevia" :ticketsPrevia="$ticketsPrevia" />
        @endcan

        {{-- / view cliente --}}
        @can('cliente')
            <x-content-home-client :ticketsPreviaCliente="$ticketsPreviaCliente" :ticketsTotalCliente="$ticketsTotalCliente" />
        @endcan
    </div>
@endsection
