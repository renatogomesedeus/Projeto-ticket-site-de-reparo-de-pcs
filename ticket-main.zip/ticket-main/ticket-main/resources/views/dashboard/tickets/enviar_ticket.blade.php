@extends('layouts.layout_dashboard', ['title' => 'Enviar ticket'])

@section('content')

    @if ($errors->any())
        <div class="alert alert-danger pb-0 mb-3">
            <ul class="">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success mb-3" role="alert">
            <i class="fas fa-check-circle me-2 fa-lg"></i>
            <strong>Ticket aberto com sucesso!</strong>
        </div>
    @endif

    <div class="row">
        <div class="col-12 col-lg-9 mb-3">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">

                    {{-- formulário --}}
                    <form action="{{ route('tickets.store') }}" method="post">
                        @csrf
                        <input type="hidden" name="nome_autor" value="{{ auth()->user()->name }}">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label for="" class="form-label">Nome</label>
                                    <input type="text" class="form-control" value="{{ auth()->user()->name }}" id=""
                                        aria-describedby="helpId" placeholder="" readonly>
                                </div>
                            </div>

                            <div class="col-12 row">
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Assunto<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="assunto" value="" id=""
                                            aria-describedby="helpId" placeholder="">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="" class="form-label">Prioridade<span
                                                class="text-danger">*</span></label>
                                        <select class="form-select" name="prioridade" id="">
                                            <option value="4">Emergência</option>
                                            <option value="3">Alta</option>
                                            <option value="2">Baixa</option>
                                            <option value="1" selected>Normal</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="mb-3">
                                    <label for="" class="form-label">Descrição<span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="descricao" id="" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="e-btn  mt-3 e-btn-primary px-4 rounded-2">
                            Enviar
                        </button>
                    </form>

                </div>
            </div>
        </div>

        {{-- resumo --}}
        <div class="col-12 col-lg-3 mb-3">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <h4 class="card-title h5 fw-bold">Resumo</h4>
                    <ul class="list-group" style="max-width: 300px">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Tickets abertos
                            <span class="badge bg-primary rounded-pill">{{ $ticket['ticketsAberto'] }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Tickets fechados
                            <span class="badge bg-primary rounded-pill">{{ $ticket['ticketsFechado'] }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Total
                            <span class="badge bg-primary rounded-pill">{{ $ticket['ticketsTotal'] }}</span>
                        </li>
                    </ul>

                </div>
            </div>
        </div>

    </div>

@endsection
