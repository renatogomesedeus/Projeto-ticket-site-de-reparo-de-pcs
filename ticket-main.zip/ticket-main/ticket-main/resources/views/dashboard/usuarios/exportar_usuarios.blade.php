@extends('layouts.layout_dashboard', ['title' => 'Exportar usuários'])

@section('content')
    <div class="card">
        <img class="card-img-top" src="holder.js/100x180/" alt="">
        <div class="card-body">
            <h4 class="card-title">Selecione uma opção para download </h4>
            <form action="{{ route('usuarios.exportar') }}" method="post">
                @csrf
                <div class="my-3">
                    <label for="formato" class="form-label">Formato do arquivo</label>
                    <select class="form-select bg-white" name="formato" id="formato">
                        <option value="XLSX" selected>Excel (xlsx)</option>
                        <option value="PDF">PDF</option>
                        <option value="HTML">HTML</option>
                    </select>
                </div>
                <button type="submit" class="e-btn  e-btn-orange e-btn-orange-gradient-2 px-4 rounded-2">Baixar</button>
            </form>

            <div class="mt-4">
                <ul class="list-group" style="max-width: 300px">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Clientes
                        <span class="badge bg-primary rounded-pill">{{ $users['totalClientes'] }}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Funcionários
                        <span class="badge bg-primary rounded-pill">{{ $users['totalFuncionarios'] }}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Administradores
                        <span class="badge bg-primary rounded-pill">{{ $users['totalAdmin'] }}</span>
                    </li>
                </ul>
            </div>

        </div>
    </div>

@endsection
