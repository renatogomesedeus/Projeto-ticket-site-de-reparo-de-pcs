@extends('layouts.layout_dashboard', ['title' => 'Usuários'])

@section('content')

    @if (session('success'))
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle me-2 fa-lg"></i>
            <strong>{{ session('success') }}</strong>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            <form action="{{ route('usuarios') }}" method="get">
                <div class="input-group mb-4">
                    <select class="form-select bg-white" id="inputGroupSelect04"
                        aria-label="Example select with button addon" name="profile">
                        <option value="3">Cliente</option>
                        <option value="2">Funcionário</option>
                        <option value="1">Admin</option>
                    </select>
                    <button class="btn btn-outline-secondary" type="submit">Filtrar</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Conta</th>
                            <th>Status</th>
                            <th class="text-truncate">Data de registro</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($users->items() as $user)
                            <tr>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    @switch($user->profile)
                                        @case('administrator')
                                            Admin
                                        @break
                                        @case('employee')
                                            Funcionário
                                        @break
                                        @default
                                            Cliente
                                    @endswitch
                                </td>
                                <td>
                                    @switch($user->status)
                                        @case('actived')
                                            <span class="badge bg-success">Ativo</span>
                                        @break
                                        @case('inactived')
                                            <span class="badge bg-danger">Inativo</span>
                                        @break
                                        @default
                                            <span class="badge bg-warning">Pendente</span>
                                    @endswitch
                                </td>
                                <td>{{ date('d/m/Y', strtotime($user->created_at)) }}</td>
                                <td class="text-truncate">
                                    @can('admin')
                                        @switch($user->status)
                                            @case('actived')
                                                <a href="{{ route('desativar_conta', $user->id) }}"
                                                    class="btn me-1 btn-sm btn-danger">
                                                    Desativar
                                                </a>
                                            @break
                                            @case('inactived')
                                                <a href="{{ route('ativar_conta', $user->id) }}"
                                                    class="btn me-1 btn-sm btn-primary">
                                                    Ativar
                                                </a>
                                            @break
                                            @default
                                                <a href="{{ route('aprovar_conta', $user->id) }}" class="btn me-1 btn-sm btn-success">
                                                    Aprovar
                                                </a>
                                        @endswitch

                                        @can('admin')
                                            @if ($user->profile == 'employee' && $user->status == 'actived')
                                                <a href="{{ route('tornar_admin', $user->id) }}"
                                                    class="btn me-1 btn-sm btn-warning">
                                                    Tornar Admin
                                                </a>
                                            @endif
                                        @endcan

                                    @elsecan('funcionario')
                                        @switch($user->status)
                                            @case('actived')
                                                <a href="{{ route('desativar_conta', $user->id) }}"
                                                    class="btn me-1 btn-sm btn-danger">
                                                    Desativar
                                                </a>
                                            @break
                                        @endswitch
                                    @endcan

                                    @can('admin')
                                        @if ($user->status == 'inactived')
                                            <a href="{{ route('deletar_user', $user->id) }}"
                                                onclick="return confirm('Tem certeza que deseja remover esse usuário?') "
                                                class="btn me-1 btn-sm btn-dark">
                                                Deletar
                                            </a>
                                        @endif
                                    @endcan

                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </div>

            {{ $users->links() }}

        </div>
    </div>

@endsection
