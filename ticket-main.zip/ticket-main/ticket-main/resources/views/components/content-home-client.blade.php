<div class="row mb-4">
    <div class="col-12 mb-3 col-md-4">
        <div
            class="px-4 py-4 e-bg-primary-gradient rounded-2 p-3 shadow text-white d-flex justify-content-between align-items-center">
            <div class="pe-3">
                <i class="fas fa-ticket-alt  fa-4x"></i>
            </div>
            <div class="text-end">
                <h2 class="fw-bolder fs-1">{{ $ticketsTotalCliente['aberto'] }}</h2>
                Tickets abertos
            </div>
        </div>
    </div>

    <div class="col-12 mb-3 col-md-4">
        <div
            class="px-4 py-4 e-bg-orange-gradient rounded-2 p-3 shadow text-white d-flex justify-content-between align-items-center">
            <div class="pe-3">
                <i class="fas fa-ticket-alt  fa-4x"></i>
            </div>
            <div class="text-end">
                <h2 class="fw-bolder fs-1">{{ $ticketsTotalCliente['fechado'] }}</h2>
                Tickets fechados
            </div>
        </div>
    </div>

    <div class="col-12 mb-3 col-md-4">
        <div
            class="px-4 py-4 e-bg-danger-gradient rounded-2 p-3 shadow text-white d-flex justify-content-between align-items-center">
            <div class="pe-3">
                <i class="fas fa-clipboard-list fa-4x"></i>
            </div>
            <div class="text-end">
                <h2 class="fw-bolder fs-1">{{ $ticketsTotalCliente['total'] }}</h2>
                Todos os tickets
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <h3 class="h4 card-title">Seus tickets</h3>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Ticket ID</th>
                        <th>Assunto</th>
                        <th>Status</th>
                        <th>Prioridade</th>
                        <th>Data de envio</th>
                    </tr>
                </thead>
                <tbody>

                    @foreach ($ticketsPreviaCliente as $ticket)
                        <tr>
                            <td>
                                <a href="{{ route('tickets.show', ['ticket' => $ticket->id]) }}"
                                    class="">#{{ $ticket->id }}</a>
                            </td>
                            <td>
                                {{ $ticket->assunto }}
                            </td>

                            <td>
                                @if ($ticket->status == 'aberto')
                                    <span class="badge bg-warning">Aberto</span>
                                @else
                                    <span class="badge bg-danger">Fechado</span>
                                @endif
                            </td>
                            <td>
                                @switch($ticket->prioridade)
                                @case(4)
                                    Emergência
                                    @break
                                @case(3)
                                    Alta
                                    @break
                                @case(2)
                                    Baixa
                                    @break
                                @default
                                    Normal
                            @endswitch
                            </td>
                            {{-- <td>10/11/2022 às 10:43pm</td> --}}
                            <td class="text-truncate">{{ date('d/m/Y à\\s h:ia', strtotime($ticket->created_at)) }}</td>
                        </tr>
                    @endforeach

                </tbody>
            </table>
        </div>

        @if (empty($ticketsPreviaCliente->toArray()))
            <div class="alert alert-info" role="alert">
                Não tem tickets.
            </div>
        @else
            <a href="{{ route('meus_tickets') }}" class="e-btn e-btn-purple">Visualizar todos</a>
        @endif


    </div>
</div>
