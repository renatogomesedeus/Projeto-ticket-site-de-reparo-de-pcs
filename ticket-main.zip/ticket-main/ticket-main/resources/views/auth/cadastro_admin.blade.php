<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-12 col-md-5 mx-auto my-5">
                <div class="card">
                    <img class="card-img-top" src="holder.js/100x180/" alt="">
                    <div class="card-body">
                        <h4 class="card-title">Preencha os campos para inserir uma conta de administrador</h4>
                        <p class="text-muted">
                            
                        </p>

                        <form action="{{ route('post_adicionar_admin') }}" method="post">
                            @csrf

                            <div class="row g-3">
                                <div class="col-12 ">
                                    <label for="name" class="form-label">Nome</label>
                                    <input type="text" class="form-control" name="name" value="{{ old('name') }}"
                                        id="name" aria-describedby="helpId" placeholder="" required>
                                </div>
                                <div class="col-12 ">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input type="text" class="form-control" name="email" value="{{ old('email') }}"
                                        id="email" aria-describedby="helpId" placeholder="" required>
                                </div>
                                <div class="col-12 ">
                                    <label for="password" class="form-label">Senha</label>
                                    <input type="password" class="form-control" name="password" id="password"
                                        aria-describedby="helpId" placeholder="" required>
                                </div>
                                <div class="col-12 ">
                                    <label for="password" class="form-label">Repetir senha</label>
                                    <input type="password" class="form-control" name="password_confirmation"
                                        id="password" aria-describedby="helpId" placeholder="" required>
                                </div>
                            </div>


                            <button type="submit"
                                class="btn  mt-3 btn-primary btn-primary-gradient-2 px-4 rounded-2">Criar
                                conta de admin</button>

                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
