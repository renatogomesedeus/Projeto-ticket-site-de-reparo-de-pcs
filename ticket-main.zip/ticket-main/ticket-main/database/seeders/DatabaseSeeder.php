<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    // vou colocar os usuarios no grafico
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\User::factory(30)->create();
        \App\Models\Ticket::factory(100)->create();
        \App\Models\Visualizacoes::factory(300)->create();
        \App\Models\Mensagem::factory(50)->create();
    }
}
