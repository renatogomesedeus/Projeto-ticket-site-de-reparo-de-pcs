<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class TicketFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'assunto' => $this->faker->sentence(2),
            'prioridade' => $this->faker->numberBetween(1, 4),
            'status' => $this->faker->randomElement( ['aberto', 'fechado']),
            'user_id' => $this->faker->numberBetween(1,30),
            'created_at' => $this->faker->unique()->dateTimeBetween('-5 months', 'now'),
        ];
    }
}
